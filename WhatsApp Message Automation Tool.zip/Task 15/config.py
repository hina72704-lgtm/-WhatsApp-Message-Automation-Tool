"""
Configuration settings for WhatsApp Automation Tool
"""
import os

# File paths
CONTACTS_FILE = "contacts.csv"
TEMPLATES_FILE = "templates.json"
LOGS_FILE = "message_logs.json"

# Message sending settings
WAIT_TIME = 15  # Seconds to wait before sending message
CLOSE_TAB = True  # Close browser tab after sending
MESSAGE_DELAY = 5  # Delay between messages in bulk sending

# Scheduling settings
SCHEDULE_CHECK_INTERVAL = 60  # Check scheduled messages every 60 seconds

# Supported file formats
SUPPORTED_CONTACT_FORMATS = ['.csv', '.json']

# Logging settings
MAX_LOG_SIZE = 1024 * 1024  # 1 MB

# Create necessary directories if they don't exist
def setup_directories():
    """Create necessary directories for logs and data"""
    directories = ['logs', 'data', 'templates']
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)

# Call setup function
setup_directories()