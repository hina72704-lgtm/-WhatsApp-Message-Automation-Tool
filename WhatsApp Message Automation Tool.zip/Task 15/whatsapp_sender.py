"""
Core WhatsApp message sending functionality
"""
import pywhatkit as kit
import time
from datetime import datetime
import pyautogui
import re
from typing import List, Dict
from logger import MessageLogger

class WhatsAppSender:
    """Handles all WhatsApp message sending operations"""
    
    def __init__(self, logger: MessageLogger):
        self.logger = logger
        self.sent_messages = set()  # Track sent messages to avoid duplicates
        
    def validate_phone_number(self, phone_number: str) -> bool:
        """Validate phone number format"""
        # Remove any non-digit characters
        cleaned = re.sub(r'\D', '', phone_number)
        
        # Check if it has country code (minimum 10 digits)
        if len(cleaned) < 10 or len(cleaned) > 15:
            return False
        
        # Check if it starts with valid country code pattern
        if not cleaned.startswith(('1', '2', '3', '4', '5', '6', '7', '8', '9')):
            return False
            
        return True
    
    def send_message(self, phone_number: str, message: str, wait_time: int = 15) -> bool:
        """Send a single WhatsApp message"""
        try:
            # Validate phone number
            if not self.validate_phone_number(phone_number):
                self.logger.add_log(phone_number, message, "Failed", "Invalid phone number")
                return False
            
            # Check for duplicate
            message_id = f"{phone_number}_{message[:50]}"
            if message_id in self.sent_messages:
                print(f"⚠️ Duplicate message detected for {phone_number}. Skipping...")
                return False
            
            # Send message using pywhatkit
            kit.sendwhatmsg_instantly(
                phone_no=f"+{phone_number}",
                message=message,
                wait_time=wait_time,
                tab_close=True,
                close_time=3
            )
            
            # Mark as sent
            self.sent_messages.add(message_id)
            
            # Log success
            self.logger.add_log(phone_number, message, "Sent")
            print(f"✅ Message sent successfully to {phone_number}")
            return True
            
        except Exception as e:
            error_msg = str(e)
            self.logger.add_log(phone_number, message, "Failed", error_msg)
            print(f"❌ Failed to send message to {phone_number}: {error_msg}")
            return False
    
    def send_bulk_messages(self, contacts: List[Dict], message_template: str, 
                          delay: int = 5) -> Dict:
        """Send messages to multiple contacts"""
        results = {
            "total": len(contacts),
            "sent": 0,
            "failed": 0,
            "details": []
        }
        
        for idx, contact in enumerate(contacts, 1):
            print(f"\n📨 Sending message {idx}/{len(contacts)}")
            
            # Personalize message if template has variables
            message = message_template
            for key, value in contact.items():
                if key != 'phone':
                    message = message.replace(f"{{{key}}}", str(value))
            
            # Send message
            success = self.send_message(contact['phone'], message)
            
            if success:
                results["sent"] += 1
                results["details"].append({
                    "phone": contact['phone'],
                    "status": "Sent"
                })
            else:
                results["failed"] += 1
                results["details"].append({
                    "phone": contact['phone'],
                    "status": "Failed"
                })
            
            # Delay between messages
            if idx < len(contacts):
                time.sleep(delay)
        
        return results
    
    def preview_message(self, phone_number: str, message: str):
        """Preview message before sending"""
        print("\n" + "="*50)
        print("📱 MESSAGE PREVIEW")
        print("="*50)
        print(f"To: {phone_number}")
        print(f"Message:\n{message}")
        print("="*50)
        confirm = input("\nSend this message? (y/n): ").lower()
        return confirm == 'y'