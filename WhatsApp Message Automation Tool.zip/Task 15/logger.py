"""
Logging system for tracking message history
"""
import json
from datetime import datetime
import os
from typing import Dict, List

class MessageLogger:
    """Handles logging of all message activities"""
    
    def __init__(self, log_file: str = "message_logs.json"):
        self.log_file = log_file
        self.logs = self.load_logs()
    
    def load_logs(self) -> List[Dict]:
        """Load existing logs from file"""
        if os.path.exists(self.log_file):
            try:
                with open(self.log_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def save_logs(self):
        """Save logs to file"""
        with open(self.log_file, 'w') as f:
            json.dump(self.logs, f, indent=2)
    
    def add_log(self, phone_number: str, message: str, status: str, error: str = None):
        """Add a new message log entry"""
        log_entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "phone_number": phone_number,
            "message": message[:100] + "..." if len(message) > 100 else message,
            "status": status,
            "error": error
        }
        self.logs.append(log_entry)
        self.save_logs()
        return log_entry
    
    def get_logs(self, limit: int = None) -> List[Dict]:
        """Retrieve logs, optionally limited"""
        if limit and limit > 0:
            return self.logs[-limit:]
        return self.logs
    
    def clear_logs(self):
        """Clear all logs"""
        self.logs = []
        self.save_logs()
    
    def get_stats(self) -> Dict:
        """Get statistics about message logs"""
        total = len(self.logs)
        sent = sum(1 for log in self.logs if log['status'] == 'Sent')
        failed = sum(1 for log in self.logs if log['status'] == 'Failed')
        
        return {
            "total": total,
            "sent": sent,
            "failed": failed,
            "success_rate": (sent/total*100) if total > 0 else 0
        }