"""
Schedule messages for future delivery
"""
import threading
import time
import schedule
from datetime import datetime
import json
import os
from typing import Dict, List
from whatsapp_sender import WhatsAppSender

class MessageScheduler:
    """Handles scheduling of messages"""
    
    def __init__(self, sender: WhatsAppSender):
        self.sender = sender
        self.scheduled_messages = []
        self.schedule_file = "scheduled_messages.json"
        self.load_scheduled_messages()
        self.scheduler_thread = None
        self.running = False
    
    def load_scheduled_messages(self):
        """Load scheduled messages from file"""
        if os.path.exists(self.schedule_file):
            try:
                with open(self.schedule_file, 'r') as f:
                    self.scheduled_messages = json.load(f)
            except:
                self.scheduled_messages = []
    
    def save_scheduled_messages(self):
        """Save scheduled messages to file"""
        with open(self.schedule_file, 'w') as f:
            json.dump(self.scheduled_messages, f, indent=2)
    
    def schedule_message(self, phone_number: str, message: str, 
                        schedule_time: str, date: str = None):
        """
        Schedule a message for specific time
        
        Args:
            phone_number: Recipient's phone number
            message: Message to send
            schedule_time: Time in HH:MM format (24-hour)
            date: Date in YYYY-MM-DD format (optional, defaults to today)
        """
        schedule_entry = {
            "id": len(self.scheduled_messages) + 1,
            "phone_number": phone_number,
            "message": message,
            "time": schedule_time,
            "date": date or datetime.now().strftime("%Y-%m-%d"),
            "status": "pending"
        }
        
        self.scheduled_messages.append(schedule_entry)
        self.save_scheduled_messages()
        print(f"✅ Message scheduled for {date or 'today'} at {schedule_time}")
        return schedule_entry
    
    def execute_scheduled_message(self, entry: Dict):
        """Execute a scheduled message"""
        current_time = datetime.now()
        scheduled_datetime = datetime.strptime(
            f"{entry['date']} {entry['time']}", 
            "%Y-%m-%d %H:%M"
        )
        
        if current_time >= scheduled_datetime and entry['status'] == 'pending':
            print(f"\n⏰ Executing scheduled message to {entry['phone_number']}")
            success = self.sender.send_message(entry['phone_number'], entry['message'])
            
            entry['status'] = 'sent' if success else 'failed'
            entry['sent_time'] = current_time.strftime("%Y-%m-%d %H:%M:%S")
            self.save_scheduled_messages()
            return True
        return False
    
    def check_scheduled_messages(self):
        """Check and execute due scheduled messages"""
        for entry in self.scheduled_messages:
            if entry['status'] == 'pending':
                self.execute_scheduled_message(entry)
    
    def start_scheduler(self, check_interval: int = 60):
        """Start the scheduler in a background thread"""
        if self.scheduler_thread and self.scheduler_thread.is_alive():
            print("Scheduler is already running")
            return
        
        self.running = True
        
        def run_scheduler():
            while self.running:
                self.check_scheduled_messages()
                time.sleep(check_interval)
        
        self.scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
        self.scheduler_thread.start()
        print("📅 Message scheduler started")
    
    def stop_scheduler(self):
        """Stop the scheduler"""
        self.running = False
        print("📅 Message scheduler stopped")
    
    def list_scheduled_messages(self):
        """List all scheduled messages"""
        if not self.scheduled_messages:
            print("\nNo scheduled messages found.")
            return
        
        print("\n" + "="*60)
        print("📅 SCHEDULED MESSAGES")
        print("="*60)
        for msg in self.scheduled_messages:
            status_icon = "✓" if msg['status'] == 'sent' else "⏰" if msg['status'] == 'pending' else "✗"
            print(f"{status_icon} ID: {msg['id']} | To: {msg['phone_number']} | "
                  f"When: {msg['date']} {msg['time']} | Status: {msg['status']}")
        print("="*60)
    
    def cancel_scheduled_message(self, message_id: int):
        """Cancel a scheduled message"""
        for msg in self.scheduled_messages:
            if msg['id'] == message_id and msg['status'] == 'pending':
                msg['status'] = 'cancelled'
                self.save_scheduled_messages()
                print(f"✅ Cancelled scheduled message ID: {message_id}")
                return True
        print(f"❌ No pending message found with ID: {message_id}")
        return False