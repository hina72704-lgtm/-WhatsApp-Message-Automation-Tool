"""
WhatsApp Message Automation Tool
Main application entry point
"""
import os
import sys
import json
import csv
from datetime import datetime
from colorama import init, Fore, Style

# Initialize colorama for colored output
init(autoreset=True)

# Import modules
from config import *
from logger import MessageLogger
from whatsapp_sender import WhatsAppSender
from template_manager import TemplateManager
from message_scheduler import MessageScheduler

class WhatsAppAutomationTool:
    """Main application class"""
    
    def __init__(self):
        """Initialize the application"""
        print(Fore.CYAN + "="*60)
        print(Fore.CYAN + "📱 WHATSAPP MESSAGE AUTOMATION TOOL")
        print(Fore.CYAN + "="*60)
        
        # Initialize components
        self.logger = MessageLogger(LOGS_FILE)
        self.sender = WhatsAppSender(self.logger)
        self.template_manager = TemplateManager(TEMPLATES_FILE)
        self.scheduler = MessageScheduler(self.sender)
        
        # Start scheduler
        self.scheduler.start_scheduler(SCHEDULE_CHECK_INTERVAL)
        
        print(Fore.GREEN + "✅ Application initialized successfully!\n")
    
    def clear_screen(self):
        """Clear the console screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def display_menu(self):
        """Display main menu"""
        print(Fore.YELLOW + "\n" + "="*40)
        print(Fore.YELLOW + "📋 MAIN MENU")
        print(Fore.YELLOW + "="*40)
        print(Fore.CYAN + "1. 📨 Send Single Message")
        print(Fore.CYAN + "2. 👥 Bulk Messaging")
        print(Fore.CYAN + "3. 📝 Use Template")
        print(Fore.CYAN + "4. ⏰ Schedule Message")
        print(Fore.CYAN + "5. 📊 View Logs")
        print(Fore.CYAN + "6. 📋 View Scheduled Messages")
        print(Fore.CYAN + "7. 🗑️ Cancel Scheduled Message")
        print(Fore.CYAN + "8. 📝 Manage Templates")
        print(Fore.CYAN + "9. 📈 View Statistics")
        print(Fore.RED + "0. 🚪 Exit")
        print(Fore.YELLOW + "="*40)
    
    def send_single_message(self):
        """Send a single WhatsApp message"""
        self.clear_screen()
        print(Fore.CYAN + "\n📨 SEND SINGLE MESSAGE")
        print("-"*30)
        
        # Get phone number
        phone = input("Enter phone number (with country code, e.g., 1234567890): ").strip()
        if not phone:
            print(Fore.RED + "❌ Phone number required!")
            return
        
        # Get message
        print(Fore.YELLOW + "\nEnter your message (press Enter twice to finish):")
        lines = []
        while True:
            line = input()
            if line == "" and len(lines) > 0:
                break
            if line:
                lines.append(line)
        message = "\n".join(lines)
        
        if not message:
            print(Fore.RED + "❌ Message cannot be empty!")
            return
        
        # Preview message
        if self.sender.preview_message(phone, message):
            self.sender.send_message(phone, message)
        else:
            print(Fore.YELLOW + "❌ Message sending cancelled.")
    
    def load_contacts(self, filename: str):
        """Load contacts from CSV or JSON file"""
        contacts = []
        
        try:
            if filename.endswith('.csv'):
                with open(filename, 'r') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        if 'phone' in row:
                            contacts.append(row)
            elif filename.endswith('.json'):
                with open(filename, 'r') as f:
                    data = json.load(f)
                    contacts = data if isinstance(data, list) else [data]
            else:
                print(Fore.RED + "❌ Unsupported file format. Use CSV or JSON.")
                return None
        except Exception as e:
            print(Fore.RED + f"❌ Error loading contacts: {e}")
            return None
        
        return contacts
    
    def bulk_messaging(self):
        """Send bulk messages to multiple contacts"""
        self.clear_screen()
        print(Fore.CYAN + "\n👥 BULK MESSAGING")
        print("-"*30)
        
        # Get contacts file
        filename = input("Enter contacts file path (CSV/JSON): ").strip()
        if not filename:
            print(Fore.RED + "❌ Filename required!")
            return
        
        contacts = self.load_contacts(filename)
        if not contacts:
            return
        
        print(Fore.GREEN + f"✅ Loaded {len(contacts)} contacts")
        
        # Get message
        print(Fore.YELLOW + "\nEnter message (use {variable} for personalization):")
        print(Fore.YELLOW + "Available variables: phone, name, course, etc.")
        message = input("Message: ").strip()
        
        if not message:
            print(Fore.RED + "❌ Message cannot be empty!")
            return
        
        # Confirm before sending
        print(Fore.YELLOW + f"\n⚠️ You are about to send messages to {len(contacts)} recipients.")
        confirm = input("Continue? (yes/no): ").lower()
        
        if confirm == 'yes':
            print(Fore.GREEN + "\n📤 Sending messages...")
            results = self.sender.send_bulk_messages(contacts, message, MESSAGE_DELAY)
            
            print(Fore.GREEN + f"\n✅ Bulk messaging completed!")
            print(Fore.CYAN + f"📊 Results: {results['sent']} sent, {results['failed']} failed")
        else:
            print(Fore.YELLOW + "❌ Bulk messaging cancelled.")
    
    def use_template(self):
        """Use a message template"""
        self.clear_screen()
        print(Fore.CYAN + "\n📝 USE TEMPLATE")
        print("-"*30)
        
        # List available templates
        templates = self.template_manager.list_templates()
        if not templates:
            print(Fore.RED + "❌ No templates available!")
            return
        
        print(Fore.GREEN + "\nAvailable templates:")
        for idx, template_name in enumerate(templates, 1):
            template = self.template_manager.get_template(template_name)
            print(f"{idx}. {template['name']} - {template['template'][:50]}...")
        
        # Select template
        choice = input("\nSelect template number (or 'new' to create): ").strip()
        
        if choice.lower() == 'new':
            self.create_template()
            return
        
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(templates):
                template_name = templates[idx]
                template = self.template_manager.get_template(template_name)
                template_text = template['template']
                
                # Get phone number
                phone = input("\nEnter phone number: ").strip()
                if not phone:
                    print(Fore.RED + "❌ Phone number required!")
                    return
                
                # Get variables
                variables = {}
                print(Fore.YELLOW + "\nEnter values for variables:")
                # Extract variables from template
                import re
                var_pattern = r'\{(\w+)\}'
                found_vars = re.findall(var_pattern, template_text)
                
                for var in set(found_vars):
                    if var != 'phone':
                        value = input(f"{var}: ").strip()
                        if value:
                            variables[var] = value
                
                # Personalize message
                message = self.template_manager.personalize_message(template_text, variables)
                
                # Send message
                if self.sender.preview_message(phone, message):
                    self.sender.send_message(phone, message)
                else:
                    print(Fore.YELLOW + "❌ Message sending cancelled.")
            else:
                print(Fore.RED + "❌ Invalid choice!")
        except ValueError:
            print(Fore.RED + "❌ Invalid input!")
    
    def create_template(self):
        """Create a new message template"""
        self.clear_screen()
        print(Fore.CYAN + "\n📝 CREATE NEW TEMPLATE")
        print("-"*30)
        
        name = input("Template name (unique identifier): ").strip()
        if not name:
            print(Fore.RED + "❌ Template name required!")
            return
        
        display_name = input("Display name: ").strip()
        if not display_name:
            display_name = name
        
        print(Fore.YELLOW + "\nEnter template text (use {variable} for personalization):")
        print(Fore.YELLOW + "Example: Hello {name}, welcome to {course}!")
        template_text = input("Template: ").strip()
        
        if not template_text:
            print(Fore.RED + "❌ Template text required!")
            return
        
        self.template_manager.add_template(name, display_name, template_text)
        print(Fore.GREEN + f"✅ Template '{display_name}' created successfully!")
    
    def schedule_message(self):
        """Schedule a message for later"""
        self.clear_screen()
        print(Fore.CYAN + "\n⏰ SCHEDULE MESSAGE")
        print("-"*30)
        
        # Get phone number
        phone = input("Enter phone number: ").strip()
        if not phone:
            print(Fore.RED + "❌ Phone number required!")
            return
        
        # Get message
        message = input("Enter message: ").strip()
        if not message:
            print(Fore.RED + "❌ Message cannot be empty!")
            return
        
        # Get schedule time
        print(Fore.YELLOW + "\nSchedule details:")
        time_str = input("Time (HH:MM in 24-hour format): ").strip()
        
        # Validate time format
        try:
            datetime.strptime(time_str, "%H:%M")
        except:
            print(Fore.RED + "❌ Invalid time format! Use HH:MM")
            return
        
        date_str = input("Date (YYYY-MM-DD, press Enter for today): ").strip()
        if date_str:
            try:
                datetime.strptime(date_str, "%Y-%m-%d")
            except:
                print(Fore.RED + "❌ Invalid date format! Use YYYY-MM-DD")
                return
        
        # Schedule the message
        self.scheduler.schedule_message(phone, message, time_str, date_str if date_str else None)
        print(Fore.GREEN + "✅ Message scheduled successfully!")
    
    def view_logs(self):
        """View message logs"""
        self.clear_screen()
        print(Fore.CYAN + "\n📊 MESSAGE LOGS")
        print("-"*30)
        
        logs = self.logger.get_logs(limit=20)
        if not logs:
            print(Fore.YELLOW + "No logs found.")
            return
        
        print(Fore.GREEN + "\nRecent Messages:")
        print("="*80)
        for log in reversed(logs):
            status_color = Fore.GREEN if log['status'] == 'Sent' else Fore.RED
            print(f"{status_color}[{log['timestamp']}] {log['status']} - To: {log['phone_number']}")
            print(f"  Message: {log['message']}")
            if log.get('error'):
                print(f"  Error: {Fore.RED}{log['error']}")
            print("-"*80)
        
        input("\nPress Enter to continue...")
    
    def view_scheduled(self):
        """View scheduled messages"""
        self.clear_screen()
        self.scheduler.list_scheduled_messages()
        input("\nPress Enter to continue...")
    
    def cancel_scheduled(self):
        """Cancel a scheduled message"""
        self.clear_screen()
        self.scheduler.list_scheduled_messages()
        
        msg_id = input("\nEnter message ID to cancel: ").strip()
        if msg_id:
            try:
                self.scheduler.cancel_scheduled_message(int(msg_id))
            except:
                print(Fore.RED + "❌ Invalid ID!")
        
        input("\nPress Enter to continue...")
    
    def manage_templates(self):
        """Manage message templates"""
        self.clear_screen()
        print(Fore.CYAN + "\n📝 MANAGE TEMPLATES")
        print("-"*30)
        
        templates = self.template_manager.list_templates()
        if templates:
            print(Fore.GREEN + "\nExisting templates:")
            for idx, template_name in enumerate(templates, 1):
                template = self.template_manager.get_template(template_name)
                print(f"{idx}. {template['name']}")
        
        print(Fore.YELLOW + "\nOptions:")
        print("1. Create new template")
        print("2. Delete template")
        print("3. Back to main menu")
        
        choice = input("\nSelect option: ").strip()
        
        if choice == '1':
            self.create_template()
        elif choice == '2':
            if templates:
                print(Fore.GREEN + "\nSelect template to delete:")
                for idx, template_name in enumerate(templates, 1):
                    print(f"{idx}. {template_name}")
                
                del_choice = input("Enter number: ").strip()
                try:
                    idx = int(del_choice) - 1
                    if 0 <= idx < len(templates):
                        confirm = input(f"Delete '{templates[idx]}'? (yes/no): ").lower()
                        if confirm == 'yes':
                            self.template_manager.delete_template(templates[idx])
                            print(Fore.GREEN + "✅ Template deleted!")
                    else:
                        print(Fore.RED + "❌ Invalid choice!")
                except:
                    print(Fore.RED + "❌ Invalid input!")
            else:
                print(Fore.RED + "❌ No templates to delete!")
        
        input("\nPress Enter to continue...")
    
    def view_statistics(self):
        """View message statistics"""
        self.clear_screen()
        print(Fore.CYAN + "\n📈 MESSAGE STATISTICS")
        print("-"*30)
        
        stats = self.logger.get_stats()
        
        print(Fore.GREEN + f"📊 Total Messages: {stats['total']}")
        print(Fore.GREEN + f"✅ Successfully Sent: {stats['sent']}")
        print(Fore.RED + f"❌ Failed: {stats['failed']}")
        print(Fore.CYAN + f"📈 Success Rate: {stats['success_rate']:.1f}%")
        
        # Show recent activity
        recent = self.logger.get_logs(limit=5)
        if recent:
            print(Fore.YELLOW + "\n📅 Recent Activity:")
            for log in recent:
                print(f"  {log['timestamp']}: {log['status']} - {log['phone_number']}")
        
        input("\nPress Enter to continue...")
    
    def run(self):
        """Main application loop"""
        while True:
            self.display_menu()
            choice = input("\nEnter your choice (0-9): ").strip()
            
            if choice == '0':
                print(Fore.YELLOW + "\n👋 Shutting down...")
                self.scheduler.stop_scheduler()
                print(Fore.GREEN + "✅ Thank you for using WhatsApp Automation Tool!")
                sys.exit(0)
            elif choice == '1':
                self.send_single_message()
            elif choice == '2':
                self.bulk_messaging()
            elif choice == '3':
                self.use_template()
            elif choice == '4':
                self.schedule_message()
            elif choice == '5':
                self.view_logs()
            elif choice == '6':
                self.view_scheduled()
            elif choice == '7':
                self.cancel_scheduled()
            elif choice == '8':
                self.manage_templates()
            elif choice == '9':
                self.view_statistics()
            else:
                print(Fore.RED + "❌ Invalid choice! Please select 0-9")

if __name__ == "__main__":
    try:
        app = WhatsAppAutomationTool()
        app.run()
    except KeyboardInterrupt:
        print(Fore.YELLOW + "\n\n👋 Application interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(Fore.RED + f"\n❌ Fatal error: {e}")
        sys.exit(1)