"""
Handle message templates with dynamic variables
"""
import json
import os
from typing import Dict, List

class TemplateManager:
    """Manages message templates and personalization"""
    
    def __init__(self, template_file: str = "templates.json"):
        self.template_file = template_file
        self.templates = self.load_templates()
    
    def load_templates(self) -> Dict:
        """Load templates from file"""
        if os.path.exists(self.template_file):
            try:
                with open(self.template_file, 'r') as f:
                    return json.load(f)
            except:
                return self.get_default_templates()
        return self.get_default_templates()
    
    def get_default_templates(self) -> Dict:
        """Return default templates"""
        return {
            "welcome": {
                "name": "Welcome Message",
                "template": "Hello {name}! Welcome to our course: {course}. We're excited to have you!"
            },
            "reminder": {
                "name": "Class Reminder",
                "template": "Hi {name}, this is a reminder for your {course} class today at 2:00 PM."
            },
            "notification": {
                "name": "Update Notification",
                "template": "Dear {name}, new updates available for {course}. Check them out!"
            }
        }
    
    def save_templates(self):
        """Save templates to file"""
        with open(self.template_file, 'w') as f:
            json.dump(self.templates, f, indent=2)
    
    def list_templates(self) -> List[str]:
        """List all available template names"""
        return list(self.templates.keys())
    
    def get_template(self, template_name: str) -> Dict:
        """Get a specific template"""
        return self.templates.get(template_name)
    
    def add_template(self, name: str, display_name: str, template_text: str):
        """Add a new template"""
        self.templates[name] = {
            "name": display_name,
            "template": template_text
        }
        self.save_templates()
    
    def delete_template(self, name: str):
        """Delete a template"""
        if name in self.templates:
            del self.templates[name]
            self.save_templates()
    
    def personalize_message(self, template_text: str, variables: Dict) -> str:
        """Replace variables in template with actual values"""
        message = template_text
        for key, value in variables.items():
            message = message.replace(f"{{{key}}}", str(value))
        return message